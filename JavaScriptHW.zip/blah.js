document.getElementById('Title1').innerHTML = "<h1>Some Text<h1>"

function myFunction(){
	alert("There are 5 Ptags.");
}

function myFunction2(){
	alert("There is 1 element.")
}

function myFunction3(){
	alert("There is only 1.")
}
